# how to build
./kernel_platform/oplus/build/oplus_build_kernel.sh sun perf